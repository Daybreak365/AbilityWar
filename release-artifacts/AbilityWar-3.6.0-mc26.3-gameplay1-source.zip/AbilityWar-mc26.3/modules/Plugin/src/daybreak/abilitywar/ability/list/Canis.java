package daybreak.abilitywar.ability.list;

import daybreak.abilitywar.ability.AbilityBase;
import daybreak.abilitywar.ability.AbilityManifest;
import daybreak.abilitywar.ability.AbilityManifest.Rank;
import daybreak.abilitywar.ability.AbilityManifest.Species;
import daybreak.abilitywar.ability.SubscribeEvent;
import daybreak.abilitywar.ability.decorator.ActiveHandler;
import daybreak.abilitywar.config.ability.AbilitySettings.SettingObject;
import daybreak.abilitywar.game.AbstractGame.Participant;
import daybreak.abilitywar.game.AbstractGame.Participant.ActionbarNotification.ActionbarChannel;
import daybreak.abilitywar.game.module.DeathManager;
import daybreak.abilitywar.game.team.interfaces.Teamable;
import daybreak.abilitywar.utils.base.color.RGB;
import daybreak.abilitywar.utils.base.concurrent.TimeUnit;
import daybreak.abilitywar.utils.base.math.LocationUtil;
import daybreak.abilitywar.utils.base.minecraft.damage.Damages;
import daybreak.abilitywar.utils.base.minecraft.nms.NMS;
import daybreak.abilitywar.utils.base.minecraft.raytrace.RayTrace;
import daybreak.abilitywar.utils.base.random.Random;
import daybreak.abilitywar.utils.library.MaterialX;
import daybreak.abilitywar.utils.library.ParticleLib;
import daybreak.abilitywar.utils.library.SoundLib;
import daybreak.abilitywar.utils.library.item.EnchantLib;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Horse;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.event.vehicle.VehicleExitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.HorseInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@AbilityManifest(name = "카니스", rank = Rank.L, species = Species.HUMAN, explain = {
        "§7패시브 §8- §3출전 준비§f: 하마 중 $[CHARGE_SECONDS]초마다 전마의 기력이 한 단계씩",
        " 충전됩니다. 최대 3단계까지 준비하며, 탑승 중에는 충전되지 않습니다.",
        "§7철괴 우클릭 §8- §3쾌속 질주§f: 1단계 이상 준비되면 기력을 모두 소모하여 전마에",
        " 탑승하고 $[DASH_SECONDS]초간 질주합니다. 단계가 높을수록 빠르게 달리며, 종료 시 자동 하마합니다.",
        "§7검 좌클릭 §8- §3기병 돌격§f: 질주 중 첫 검 좌클릭으로 전마와 함께 전방으로 짧게",
        " 돌진하며 충전된 랜스를 찌릅니다. 직접 적을 클릭하지 않아도 경로의 적에게 검 공격력의",
        " 50% / 75% / 100%만큼 방어 관통 피해를 줍니다. 질주 한 번당 한 번 사용합니다.",
        "§7패시브 §8- §3하나가 되어§f: 하마하면 말의 남은 체력 70%를 §e흡수 체력§f으로",
        " 전환합니다. §e흡수 체력§f은 기존과 같이 2초 후 빠르게 사라집니다.",
        "§7패시브 §8- §3저지 불가§f: 넉백 또는 끌어당겨지는 효과를 받지 않습니다."
}, summarize = {
        "하마 중 전마의 기력을 §63단계§f까지 준비합니다.",
        "§7철괴 우클릭§f으로 전마에 탑승해 §b쾌속 질주§f하고, 종료 시 자동 하마합니다.",
        "질주 중 §7첫 검 좌클릭§f으로 짧게 돌진하며 §3방어 관통 랜스 공격§f을 합니다.",
        "하마 시 말의 남은 체력 일부를 잠시 유지되는 §e흡수 체력§f으로 전환합니다.",
        "§3넉백§f 및 §3그랩§f 영향을 받지 않습니다."
})
public class Canis extends AbilityBase implements ActiveHandler {

    public static final SettingObject<Integer> CHARGE_SECONDS = abilitySettings.new SettingObject<Integer>(Canis.class, "charge-seconds", 8,
            "# 하마 중 기력 한 단계를 준비하는 시간 (초)", "# 최대 3단계") {
        @Override public boolean condition(Integer value) { return value >= 1; }
    };
    public static final SettingObject<Integer> DASH_SECONDS = abilitySettings.new SettingObject<Integer>(Canis.class, "dash-seconds", 8,
            "# 탑승 후 자동 하마까지의 쾌속 질주 시간 (초)") {
        @Override public boolean condition(Integer value) { return value >= 1; }
    };

    private enum Tier {
        RELAXED(BarColor.BLUE, RGB.of(110, 210, 255), .3, .5),
        POISED(BarColor.PURPLE, RGB.of(150, 130, 255), .55, .75),
        EXCITED(BarColor.YELLOW, RGB.of(255, 205, 95), .9, 1);

        private final BarColor barColor;
        private final RGB color;
        private final double speed, lanceMultiplier;
        Tier(BarColor barColor, RGB color, double speed, double lanceMultiplier) {
            this.barColor = barColor;
            this.color = color;
            this.speed = speed;
            this.lanceMultiplier = lanceMultiplier;
        }
    }

    private static final Random random = new Random();
    private final Horse.Style horseStyle = random.pick(Horse.Style.class);
    private final Horse.Color horseColor = random.pick(Horse.Color.class);
    private final int chargeTicks = CHARGE_SECONDS.getValue() * 20, durationTicks = DASH_SECONDS.getValue() * 20;
    private final ActionbarChannel channel = newActionbarChannel();
    private final Cycle cycle = new Cycle();
    private Horse horse;
    private int preparationTicks, dashTicks;
    private Tier dashTier;
    private boolean lanceReady, dealingLanceDamage;
    private LanceDash lanceDash;
    private Absorption absorption;

    public Canis(Participant participant) { super(participant); }

    private int preparedTier() { return Math.min(3, preparationTicks / chargeTicks); }

    private class Cycle extends AbilityTimer {
        private final BossBar bar = Bukkit.createBossBar("전마 준비", BarColor.BLUE, BarStyle.SEGMENTED_10);
        private Cycle() { setPeriod(TimeUnit.TICKS, 1); register(); }
        @Override protected void onStart() { bar.addPlayer(getPlayer()); updateDisplay(); }
        @Override protected void run(int count) {
            if (getPlayer().isDead()) {
                unmount(false);
                preparationTicks = 0;
                updateDisplay();
                return;
            }
            if (isMounted()) {
                if (!horse.isValid() || !horse.equals(getPlayer().getVehicle())) {
                    unmount(true);
                } else if (--dashTicks <= 0) {
                    unmount(true);
                } else {
                    if (count % 2 == 0) trail();
                    if (count % 10 == 0) SoundLib.ENTITY_HORSE_GALLOP.playSound(horse.getLocation(), .7f, 1.1f);
                }
            } else if (preparationTicks < chargeTicks * 3) {
                final int before = preparedTier();
                preparationTicks++;
                if (preparedTier() > before) {
                    SoundLib.ENTITY_EXPERIENCE_ORB_PICKUP.playSound(getPlayer().getLocation(), .6f, 1 + preparedTier() * .2f);
                    ring(getPlayer().getLocation(), Tier.values()[preparedTier() - 1].color, .8);
                }
            }
            if (count % 4 == 0) updateDisplay();
        }
        private void updateDisplay() {
            if (isMounted()) {
                bar.setColor(dashTier.barColor);
                bar.setTitle("쾌속 질주 · " + (dashTier.ordinal() + 1) + "단계 · " + (lanceReady ? "랜스 준비" : "랜스 사용 완료"));
                bar.setProgress(Math.max(0, Math.min(1, dashTicks / (double) durationTicks)));
                channel.update(lanceReady ? "§b검 좌클릭 §f: 기병 돌격 §8| §7웅크리기: 하마" : "§3쾌속 질주 §8| §7웅크리기: 하마");
            } else {
                final int tier = preparedTier();
                bar.setColor(tier == 0 ? BarColor.BLUE : Tier.values()[tier - 1].barColor);
                bar.setTitle("전마 준비 · " + tier + "/3단계" + (tier == 3 ? " · 완충" : ""));
                bar.setProgress(preparationTicks / (double) (chargeTicks * 3));
                channel.update(tier > 0 ? "§b철괴 우클릭 §f: " + tier + "단계 쾌속 질주" : "§7전마가 출전을 준비하고 있습니다.");
            }
        }
        @Override protected void onEnd() { onSilentEnd(); }
        @Override protected void onSilentEnd() { bar.removeAll(); channel.update(null); }
    }

    public boolean mount() {
        if (isRestricted() || isMounted() || getPlayer().isInsideVehicle()) return false;
        final int tier = preparedTier();
        if (tier == 0) {
            getPlayer().sendMessage("§c전마의 기력이 1단계 이상 준비되어야 합니다.");
            return false;
        }
        final Horse summoned = getPlayer().getWorld().spawn(getPlayer().getLocation(), Horse.class);
        summoned.setStyle(horseStyle);
        summoned.setColor(horseColor);
        summoned.setAdult();
        summoned.setOwner(getPlayer());
        summoned.setTamed(true);
        summoned.setCustomName("§b카니스의 전마");
        summoned.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(60);
        summoned.getAttribute(Attribute.GENERIC_ARMOR).setBaseValue(12);
        summoned.setHealth(60);
        summoned.getInventory().setArmor(MaterialX.IRON_HORSE_ARMOR.createItem());
        summoned.getInventory().setSaddle(MaterialX.SADDLE.createItem());
        summoned.setJumpStrength(.7);
        summoned.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).setBaseValue(.225 * (1 + Tier.values()[tier - 1].speed));
        if (!summoned.addPassenger(getPlayer())) {
            summoned.remove();
            return false;
        }
        horse = summoned;
        dashTier = Tier.values()[tier - 1];
        dashTicks = durationTicks;
        preparationTicks = 0;
        lanceReady = true;
        ring(summoned.getLocation(), dashTier.color, 1.5);
        ParticleLib.CLOUD.spawnParticle(summoned.getLocation().add(0, .2, 0), .5, .15, .5, 12, .06);
        SoundLib.ENTITY_HORSE_SADDLE.playSound(summoned.getLocation());
        SoundLib.ENTITY_HORSE_AMBIENT.playSound(summoned.getLocation(), .7f, 1.15f);
        cycle.updateDisplay();
        return true;
    }

    public boolean unmount(boolean grantAbsorption) {
        final Horse previous = horse;
        if (previous == null) return false;
        // Clear the reference before eject/remove: both may fire VehicleExitEvent again.
        horse = null;
        dashTicks = 0;
        lanceReady = false;
        if (lanceDash != null) lanceDash.stop(true);
        if (grantAbsorption && previous.isValid() && !previous.isDead() && !getPlayer().isDead()) {
            if (absorption != null) absorption.stop(true);
            absorption = new Absorption(previous.getHealth() * .7);
            absorption.start();
            ring(previous.getLocation(), dashTier.color, 1.2);
            ParticleLib.CLOUD.spawnParticle(previous.getLocation().add(0, .5, 0), .5, .3, .5, 12, .04);
            SoundLib.ENTITY_HORSE_BREATHE.playSound(previous.getLocation(), .7f, .9f);
        }
        previous.eject();
        previous.remove();
        cycle.updateDisplay();
        return true;
    }

    public boolean isMounted() { return horse != null; }
    public boolean isLanceReady() { return isMounted() && dashTicks > 0 && lanceReady; }

    @Override public boolean ActiveSkill(Material material, ClickType clickType) {
        return material == Material.IRON_INGOT && clickType == ClickType.RIGHT_CLICK && mount();
    }

    private boolean isSword() { return getPlayer().getInventory().getItemInMainHand().getType().name().endsWith("_SWORD"); }

    @SubscribeEvent(onlyRelevant = true)
    private void onPlayerInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND || e.useItemInHand() == Event.Result.DENY) return;
        if ((e.getAction() == Action.LEFT_CLICK_AIR || e.getAction() == Action.LEFT_CLICK_BLOCK) && launchLance()) e.setCancelled(true);
    }

    @SubscribeEvent(ignoreCancelled = true)
    private void onEntityDamageByEntity(EntityDamageByEntityEvent e) {
        if (dealingLanceDamage || !getPlayer().equals(e.getDamager()) || !isSword()) return;
        if (e.getCause() != DamageCause.ENTITY_ATTACK && e.getCause() != DamageCause.ENTITY_SWEEP_ATTACK) return;
        // Entity attacks and air/block clicks share the same single-use lance.
        if (lanceDash != null || launchLance()) e.setCancelled(true);
    }

    private boolean launchLance() {
        if (isRestricted() || !isLanceReady() || !isSword() || lanceDash != null) return false;
        lanceReady = false;
        lanceDash = new LanceDash();
        lanceDash.start();
        cycle.updateDisplay();
        return true;
    }

    private boolean canHit(Entity entity) {
        if (entity.equals(getPlayer()) || entity.equals(horse) || entity instanceof ArmorStand || !entity.isValid() || entity.isDead()) return false;
        if (entity instanceof Player) {
            if (!getGame().isParticipating(entity.getUniqueId())
                    || !getGame().getParticipant(entity.getUniqueId()).attributes().TARGETABLE.getValue()
                    || (getGame() instanceof DeathManager.Handler && ((DeathManager.Handler) getGame()).getDeathManager().isExcluded(entity.getUniqueId()))) return false;
            if (getGame() instanceof Teamable) {
                final Teamable team = (Teamable) getGame();
                final Participant target = getGame().getParticipant(entity.getUniqueId());
                if (team.hasTeam(getParticipant()) && team.hasTeam(target) && team.getTeam(getParticipant()).equals(team.getTeam(target))) return false;
            }
        }
        return true;
    }

    private class LanceDash extends AbilityTimer {
        private final Set<UUID> hit = new HashSet<>();
        private final Horse mount = horse;
        private final Vector direction;
        private final float damage;
        private final RGB color = dashTier.color;
        private Location previous = mount.getLocation();
        private double distance;
        private LanceDash() {
            super(TaskType.NORMAL, 6);
            setPeriod(TimeUnit.TICKS, 1);
            final double yaw = Math.toRadians(getPlayer().getLocation().getYaw());
            direction = new Vector(-Math.sin(yaw), 0, Math.cos(yaw));
            final ItemStack sword = getPlayer().getInventory().getItemInMainHand();
            damage = (float) (EnchantLib.getDamageWithSharpnessEnchantment(getPlayer().getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).getValue(),
                    sword.getEnchantmentLevel(Enchantment.DAMAGE_ALL)) * dashTier.lanceMultiplier);
        }
        @Override protected void onStart() {
            SoundLib.ENTITY_PLAYER_ATTACK_SWEEP.playSound(mount.getLocation(), 1, .7f);
        }
        @Override protected void run(int count) {
            if (horse != mount || !mount.isValid() || !mount.equals(getPlayer().getVehicle()) || previous.getWorld() != mount.getWorld()) { stop(true); return; }
            final Location current = mount.getLocation();
            distance += previous.distance(current);
            if (distance >= 3 || blocked(current, direction.clone().multiply(.5))) { stop(false); return; }
            final Location start = previous.clone().add(0, 1, 0), end = current.clone().add(0, 1, 0).add(direction.clone().multiply(1.5));
            for (LivingEntity target : LocationUtil.rayTraceEntities(LivingEntity.class, start, end, .65, Canis.this::canHit)) {
                final Location aim = target.getLocation().add(0, Math.min(1, target.getEyeHeight()), 0);
                if (hit.contains(target.getUniqueId()) || RayTrace.hitsBlock(start.getWorld(), start.getX(), start.getY(), start.getZ(), aim.getX(), aim.getY(), aim.getZ())) continue;
                hit.add(target.getUniqueId());
                dealingLanceDamage = true;
                try { Damages.damageFixed(target, getPlayer(), damage); }
                finally { dealingLanceDamage = false; }
                ParticleLib.CRIT.spawnParticle(aim, .2, .3, .2, 12, .1);
                SoundLib.BLOCK_ANVIL_LAND.playSound(aim, .4f, 1.7f);
            }
            final Vector velocity = direction.clone().multiply(.5);
            velocity.setY(mount.getVelocity().getY());
            NMS.dashVehicle(mount, velocity);
            // Two tapering strands read as a lance rather than filling the rider's view.
            for (int i = 0; i < 8; i++) {
                final Location point = current.clone().add(0, 1.1, 0).add(direction.clone().multiply(i * .25));
                ParticleLib.REDSTONE.spawnParticle(point, color);
                if (i % 2 == 0) ParticleLib.REDSTONE.spawnParticle(point.clone().add(0, .12, 0), RGB.WHITE);
            }
            previous = current;
        }
        private boolean blocked(Location from, Vector movement) {
            final Vector side = new Vector(-direction.getZ(), 0, direction.getX()).multiply(.55);
            for (double height : new double[] {.5, 1.5, 2.7}) {
                for (int offset = -1; offset <= 1; offset++) {
                    final Location a = from.clone().add(side.clone().multiply(offset)).add(0, height, 0), b = a.clone().add(movement);
                    if (RayTrace.hitsBlock(a.getWorld(), a.getX(), a.getY(), a.getZ(), b.getX(), b.getY(), b.getZ())) return true;
                }
            }
            return false;
        }
        @Override protected void onEnd() { onSilentEnd(); }
        @Override protected void onSilentEnd() {
            if (mount.isValid()) mount.setVelocity(new Vector(0, mount.getVelocity().getY(), 0));
            lanceDash = null;
        }
    }

    private void trail() {
        final Location base = horse.getLocation().add(0, .15, 0);
        final double yaw = Math.toRadians(horse.getLocation().getYaw());
        for (int side : new int[] {-1, 1}) {
            ParticleLib.REDSTONE.spawnParticle(base.clone().add(Math.cos(yaw) * .4 * side, 0, Math.sin(yaw) * .4 * side), dashTier.color);
        }
        ParticleLib.CLOUD.spawnParticle(base, .25, .08, .25, 2, .025);
    }

    private void ring(Location center, RGB color, double radius) {
        for (int i = 0; i < 24; i++) {
            final double angle = i * Math.PI / 12;
            ParticleLib.REDSTONE.spawnParticle(center.clone().add(Math.cos(angle) * radius, .15, Math.sin(angle) * radius), color);
        }
    }

    // Keep the original dismount conversion: 70% of remaining horse HP,
    // two seconds of grace, then lose two absorption points per tick.
    private class Absorption extends AbilityTimer {
        private final float original;
        private final double amount;
        private Absorption(double amount) {
            super(TaskType.REVERSE, (int) Math.ceil(amount / 2));
            this.amount = amount;
            this.original = NMS.getAbsorptionHearts(getPlayer());
            setPeriod(TimeUnit.TICKS, 1);
            setInitialDelay(TimeUnit.SECONDS, 2);
        }
        @Override protected void onStart() { NMS.setAbsorptionHearts(getPlayer(), (float) (original + amount)); }
        @Override protected void run(int count) {
            final float current = NMS.getAbsorptionHearts(getPlayer());
            if (current <= original) { stop(false); return; }
            NMS.setAbsorptionHearts(getPlayer(), Math.max(original, current - 2));
        }
        @Override protected void onSilentEnd() {
            NMS.setAbsorptionHearts(getPlayer(), Math.min(NMS.getAbsorptionHearts(getPlayer()), original));
        }
    }

    @SubscribeEvent(ignoreCancelled = true)
    private void onVehicleExit(VehicleExitEvent e) {
        if (getPlayer().equals(e.getExited()) && e.getVehicle().equals(horse)) unmount(true);
    }
    @SubscribeEvent
    private void onEntityDeath(EntityDeathEvent e) {
        if (e.getEntity().equals(horse)) { e.getDrops().clear(); unmount(false); }
        if (e.getEntity().equals(getPlayer())) { unmount(false); preparationTicks = 0; }
    }
    @SubscribeEvent
    private void onInventoryClick(InventoryClickEvent e) {
        if (getPlayer().equals(e.getWhoClicked()) && isMounted() && e.getClickedInventory() instanceof HorseInventory) e.setCancelled(true);
    }
    @SubscribeEvent(onlyRelevant = true)
    private void onPlayerQuit(PlayerQuitEvent e) { cleanup(); }
    @SubscribeEvent(onlyRelevant = true)
    private void onPlayerJoin(PlayerJoinEvent e) { if (!isRestricted()) cycle.start(); }
    @SubscribeEvent(onlyRelevant = true)
    private void onVelocity(PlayerVelocityEvent e) { e.setCancelled(true); }

    private void cleanup() {
        unmount(false);
        preparationTicks = 0;
        cycle.stop(true);
        if (absorption != null) absorption.stop(true);
    }
    @Override protected void onUpdate(Update update) {
        if (update == Update.RESTRICTION_CLEAR) cycle.start();
        else if (update == Update.RESTRICTION_SET || update == Update.ABILITY_DESTROY) cleanup();
    }
}
